package com.ibm.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ibm.entity.Cibil;

public interface CibilRepository extends JpaRepository<Cibil, String>{


}
