package com.ibm.entity;

public class EMIChart {
	private double year;
	private double openingBal;
	private double emi;
	private double InterestPaidYearly;
	private double PrinciplePaidYearly;
	private double Closingbal;
	

	public double getYear() {
		return year;
	}

	public void setYear(double year) {
		this.year = year;
	}

	public double getOpeningBal() {
		return openingBal;
	}

	public void setOpeningBal(double openingBal) {
		this.openingBal = openingBal;
	}

	public double getEmi() {
		return emi;
	}

	public void setEmi(double emi) {
		this.emi = emi;
	}

	public double getInterestPaidYearly() {
		return InterestPaidYearly;
	}

	public void setInterestPaidYearly(double interestPaidYearly) {
		InterestPaidYearly = interestPaidYearly;
	}

	public double getPrinciplePaidYearly() {
		return PrinciplePaidYearly;
	}

	public void setPrinciplePaidYearly(double principlePaidYearly) {
		PrinciplePaidYearly = principlePaidYearly;
	}

	public double getClosingbal() {
		return Closingbal;
	}

	public void setClosingbal(double closingbal) {
		Closingbal = closingbal;
	}

	
	
	
}
