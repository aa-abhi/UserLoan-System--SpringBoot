package com.ibm.entity;
/**
 * 
 * @author Harsh Anand
 *
 */
public class LoanStatus {
	private int status;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
}
